To test this code you need to:
First: 
    Download this file into a linux environment
Test process:
    (Inside Linux Terminal)
    cd processes/
    make
    ./produce.out num1 num2 num3 num4
    (num1, num2, num3, num4 must be an integar)
Test threads:
    (Inside Linux Terminal)
    cd threads/
    make
    ./produce.out num1 num2 num3 num4
    (num1, num2, num3, num4 must be an integar)
